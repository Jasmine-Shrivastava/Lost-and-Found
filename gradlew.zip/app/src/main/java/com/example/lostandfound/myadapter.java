package com.example.lostandfound;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class myadapter extends FirebaseRecyclerAdapter<model,myadapter.myviewholder>
{
    public myadapter(@NonNull FirebaseRecyclerOptions<model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull model model)
    {
        holder.name_lost.setText(model.getName_lost());
        holder.roll_number_lost.setText(model.getRoll_number_lost());
        holder.phone_number_lost.setText(model.getPhone_number_lost());
        holder.item_lost.setText(model.getItem_lost());
        holder.place_lost.setText(model.getPlace_lost());
        Glide.with(holder.imglink_lost.getContext()).load(model.getImglink_lost()).into(holder.imglink_lost);


    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{

        ImageView imglink_lost;
        TextView name_lost,roll_number_lost,phone_number_lost,item_lost,place_lost;

        public myviewholder(@NonNull View itemView) {
            super(itemView);

            imglink_lost = (ImageView)itemView.findViewById(R.id.img1);
            name_lost = (TextView)itemView.findViewById(R.id.nametext);
            roll_number_lost = (TextView)itemView.findViewById(R.id.rolltext);
            phone_number_lost = (TextView)itemView.findViewById(R.id.phontext);
            item_lost = (TextView)itemView.findViewById(R.id.itemtext);
            place_lost = (TextView)itemView.findViewById(R.id.placetext);

        }
    }
}
