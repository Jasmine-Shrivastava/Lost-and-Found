package com.example.lostandfound;

public class model
{

    String name_lost,roll_number_lost,phone_number_lost,item_lost,place_lost,imglink_lost;

    model()
    {

    }

    public model(String name_lost, String roll_number_lost, String phone_number_lost, String item_lost, String place_lost, String imglink_lost) {
        this.name_lost = name_lost;
        this.roll_number_lost = roll_number_lost;
        this.phone_number_lost = phone_number_lost;
        this.item_lost = item_lost;
        this.place_lost = place_lost;
        this.imglink_lost = imglink_lost;
    }

    public String getName_lost() {
        return name_lost;
    }

    public void setName_lost(String name_lost) {
        this.name_lost = name_lost;
    }

    public String getRoll_number_lost() {
        return roll_number_lost;
    }

    public void setRoll_number_lost(String roll_number_lost) {
        this.roll_number_lost = roll_number_lost;
    }

    public String getPhone_number_lost() {
        return phone_number_lost;
    }

    public void setPhone_number_lost(String phone_number_lost) {
        this.phone_number_lost = phone_number_lost;
    }

    public String getItem_lost() {
        return item_lost;
    }

    public void setItem_lost(String item_lost) {
        this.item_lost = item_lost;
    }

    public String getPlace_lost() {
        return place_lost;
    }

    public void setPlace_lost(String place_lost) {
        this.place_lost = place_lost;
    }

    public String getImglink_lost() {
        return imglink_lost;
    }

    public void setImglink_lost(String imglink_lost) {
        this.imglink_lost = imglink_lost;
    }
}
